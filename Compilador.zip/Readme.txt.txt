Luis Aguirre Galindo y Javier Pellejero Ortega. Doble grado Ingenier�a Inform�tica y Matem�ticas.

El comprimido contiene:

	� La especificaci�n del lenguaje: Hemos de decir que por falta de tiempo hemos decidido
	  eliminar la implementaci�n de funciones en nuestro c�digo.

	� Carpeta Project: Contiene los archivos JLlexico.flex y JLsintactico.cup junto a las clases
	  generadas en Java por JFlex y Cup (dichos archivos .java est�n tambi�n presente en la
	  carpeta JL).

	� Carpeta JL: Contiene un proyecto Java (importable desde Eclipse) con todo el c�digo
	  del compilador, incluidos los .java generados por Jflex y Cup. Por supuesto incluye
	  los m�todos necesarios para realizar correctamente las distintas fases de la compilaci�n.

	� Carpeta CodEjemplos: Contiene una serie de ejemplos escritos en nuestro lenguaje (archivos
	  del tipo .jl) y sus correspondientes versiones en c�digo p (archivos del tipo .p).


	Comentar tambi�n que somos conscientes del retraso y que si es inadmisble esta entrega por correo, no
nos ser�a un gran incoveniente el presenterla en septiembre. Hemos tratado de contactarte para exponerte nuestros
problemas en otro correo, pero queremos recalcar que a causa de las recuperaciones del primer cuatrimestre que ambos
ten�amos, no hemos podido disponer del tiempo necesario para terminar esta pr�ctica con tiempo y tranquilidad.

