package codeGeneration;

public class OR extends P {
	
	@Override
	public String code() {
		return "or;\n";
	}

}