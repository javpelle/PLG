package codeGeneration;

public class SUB extends P {
	
	@Override
	public String code() {
		return "sub;\n";
	}

}