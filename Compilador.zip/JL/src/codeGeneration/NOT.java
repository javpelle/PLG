package codeGeneration;

public class NOT extends P {
	
	@Override
	public String code() {
		return "not;\n";
	}

}