package codeGeneration;

public class LEQ extends P {
	
	@Override
	public String code() {
		return "leq;\n";
	}

}