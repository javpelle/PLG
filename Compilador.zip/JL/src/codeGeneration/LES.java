package codeGeneration;

public class LES extends P {
	
	@Override
	public String code() {
		return "les;\n";
	}

}