package codeGeneration;

public class NEQ extends P {
	
	@Override
	public String code() {
		return "neq;\n";
	}

}