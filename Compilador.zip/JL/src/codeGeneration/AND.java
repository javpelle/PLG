package codeGeneration;

public class AND extends P{

	@Override
	public String code() {
		return "and;\n";
	}

}
