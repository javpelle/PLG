package codeGeneration;

public class STP extends P{

	@Override
	public String code() {
		return "stp;\n";
	}

}
