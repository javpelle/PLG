package codeGeneration;

public class STO extends P {
	@Override
	public String code() {
		return "sto;\n";
	}

}
