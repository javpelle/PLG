package codeGeneration;

public class MUL extends P {
	
	@Override
	public String code() {
		return "mul;\n";
	}

}