package codeGeneration;

public class DIV extends P {
	
	@Override
	public String code() {
		return "div;\n";
	}

}