package codeGeneration;

public class ADD extends P {
	
	@Override
	public String code() {
		return "add;\n";
	}

}