package codeGeneration;

public class IND extends P {

	@Override
	public String code() {
		return "ind;\n";
	}

}
