package codeGeneration;

public class EQU extends P {
	
	@Override
	public String code() {
		return "equ;\n";
	}

}