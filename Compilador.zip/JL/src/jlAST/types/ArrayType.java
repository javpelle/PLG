package jlAST.types;

public abstract class ArrayType extends Type {
	
	protected ArrayType(){}

}
